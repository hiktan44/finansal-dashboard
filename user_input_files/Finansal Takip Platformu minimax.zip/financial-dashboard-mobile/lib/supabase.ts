import 'react-native-url-polyfill/auto';
import { createClient } from '@supabase/supabase-js';
import AsyncStorage from '@react-native-async-storage/async-storage';

const supabaseUrl = 'https://twbromyqdzzjdddqaivs.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR3YnJvbXlxZHp6amRkZHFhaXZzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjIyOTM3MjMsImV4cCI6MjA3Nzg2OTcyM30.jrYmX6yy8OSlOw5Vv1xRDxoxvhAuRmnB3D34A3G7W9o';

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    storage: AsyncStorage as any,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

// Types for our financial data
export interface MarketIndex {
  id: string;
  name: string;
  symbol: string;
  close: number;
  change: number;
  changePercent: number;
  date: string;
  isNewHigh: boolean;
}

export interface TechStock {
  id: string;
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  date: string;
  marketCap?: number;
  volume?: number;
}

export interface Portfolio {
  id: string;
  user_id: string;
  name: string;
  description?: string;
  created_at: string;
}

export interface PortfolioHolding {
  id: string;
  portfolio_id: string;
  symbol: string;
  quantity: number;
  avg_purchase_price: number;
  purchase_date: string;
  notes?: string;
}

export interface UserAlert {
  id: string;
  user_id: string;
  symbol: string;
  alert_type: 'price_target' | 'percentage_change' | 'volume_spike' | 'volatility';
  condition: 'above' | 'below';
  threshold: number;
  notification_methods: ('push' | 'email')[];
  is_active: boolean;
  created_at: string;
}