CREATE TABLE market_summary (
    id BIGSERIAL PRIMARY KEY,
    summary_text TEXT,
    key_points TEXT[],
    market_sentiment VARCHAR(50),
    data_date DATE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);