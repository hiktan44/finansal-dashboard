CREATE TABLE tech_stocks (
    id BIGSERIAL PRIMARY KEY,
    symbol VARCHAR(20) NOT NULL,
    name VARCHAR(255) NOT NULL,
    close_price DECIMAL(12,2),
    change_percent DECIMAL(8,2),
    day_high DECIMAL(12,2),
    day_low DECIMAL(12,2),
    volume BIGINT,
    note TEXT,
    data_date DATE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);