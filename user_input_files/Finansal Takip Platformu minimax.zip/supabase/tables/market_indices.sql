CREATE TABLE market_indices (
    id BIGSERIAL PRIMARY KEY,
    symbol VARCHAR(20) NOT NULL,
    name VARCHAR(255) NOT NULL,
    close_price DECIMAL(12,2),
    change_value DECIMAL(12,2),
    change_percent DECIMAL(8,2),
    is_new_high BOOLEAN DEFAULT false,
    monthly_change DECIMAL(8,2),
    quarterly_change DECIMAL(8,2),
    note TEXT,
    data_date DATE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);