import React from 'react'
import { Volume2, Play, Pause } from 'lucide-react'
import { useState } from 'react'

const VoiceControl: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentSection, setCurrentSection] = useState<string | null>(null)

  const playSection = (section: string) => {
    if (isPlaying && currentSection === section) {
      // Oynatmayı durdur
      setIsPlaying(false)
      setCurrentSection(null)
      console.log(`${section} oynatmayı durdur`)
    } else {
      // Oynatmaya başla
      setIsPlaying(true)
      setCurrentSection(section)
      console.log(`${section} oynatmayı başlat`)
      
      // Oynatma süresini simüle et (3 saniye sonra otomatik durur)
      setTimeout(() => {
        setIsPlaying(false)
        setCurrentSection(null)
      }, 3000)
    }
  }

  return (
    <div className="flex items-center space-x-2">
      <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 rounded-lg p-2 border border-yellow-500/30">
        <Volume2 className={`h-5 w-5 ${
          isPlaying ? 'text-yellow-400 animate-pulse' : 'text-yellow-500'
        }`} />
      </div>
      
      <div className="hidden md:flex items-center space-x-2">
        <button
          onClick={() => playSection('Genel Bakış')}
          className={`px-3 py-1 rounded-md text-sm font-medium transition-all ${
            currentSection === 'Genel Bakış' && isPlaying
              ? 'bg-yellow-500 text-gray-900'
              : 'bg-yellow-500/20 text-yellow-500 hover:bg-yellow-500/30'
          }`}
        >
          {currentSection === 'Genel Bakış' && isPlaying ? (
            <Pause className="h-3 w-3" />
          ) : (
            <Play className="h-3 w-3" />
          )}
        </button>
        
        <span className="text-gray-400 text-sm">
          {isPlaying ? `Oynatılıyor: ${currentSection}` : 'Ses Oynatma'}
        </span>
      </div>
    </div>
  )
}

export default VoiceControl
