# PDF Çıkarma Raporu

## Genel İstatistikler
- **Toplam Dosya:** 1
- **Başarılı:** 1
- **Başarısız:** 0
- **Başarı Oranı:** 100.0%

## Format Dağılımı
- **Text_Based:** 1 dosya (100.0%)

## İşleme Detayları
### Başarılı Dosyalar

#### test.pdf
- **Format:** text_based
- **Strateji:** combined
- **Zaman:** 2025-11-08T19:19:22

## Öneriler
1. Format tespiti başarı oranı: 100.0%
2. En sık karşılaşılan format: text_based
3. Çıkarma stratejileri optimize edilebilir
