# PDF Çıkarma Raporu

## Genel İstatistikler
- **Toplam Dosya:** 1
- **Başarılı:** 1
- **Başarısız:** 0
- **Başarı Oranı:** 100.0%

## Format Dağılımı
- **Table_Heavy:** 1 dosya (100.0%)

## İşleme Detayları
### Başarılı Dosyalar

#### 45685006-0af8-42de-806a-1b8b00a19057.pdf
- **Format:** table_heavy
- **Strateji:** combined
- **Zaman:** 2025-11-08T19:20:14.657607

## Öneriler
1. Format tespiti başarı oranı: 100.0%
2. En sık karşılaşılan format: table_heavy
3. Çıkarma stratejileri optimize edilebilir
